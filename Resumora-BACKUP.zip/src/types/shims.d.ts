declare module '*.js';

/**
 * MAPE-K Self-Healing for resumora.net
 * Monitor → Analyze → Plan → Execute → Knowledge (+ Guardian + HITL)
 *
 * Safe auto-remediation only. Critical actions (secrets, migrations, restarts,
 * CDN purge / env rollback) create approval tickets — never applied silently.
 * Never logs full sk_live_ / pk_live_ / whsec_ / price_ values.
 */
const crypto = require('crypto');
const { FieldValue, Timestamp } = require('firebase-admin/firestore');
const {
  advanceHealStateMachine,
  loadState: loadHealStateMachine,
} = require('./lib/healStateMachine');
const { isAutoAckEnabled, isHighConfidenceAction } = require('./lib/autoAck');

const HEALTH_COL = 'system_health';
const HEALTH_DOC = 'current';
const INCIDENTS_COL = 'system_incidents';
const REMEDIATIONS_COL = 'system_remediations';
const APPROVALS_COL = 'system_heal_approvals';
const NOTIFY_COL = 'notification_history';
const CIRCUIT_COL = 'system_circuit_breakers';
const FIRST_FIX_COL = 'system_first_time_fixes';
/** Wider window reduces flap when the same env-drift finding repeats every scheduler tick. */
const CIRCUIT_WINDOW_MS = Number(process.env.SELF_HEAL_CIRCUIT_WINDOW_MS || 15 * 60 * 1000);
const CIRCUIT_TRIP_COUNT = Number(process.env.SELF_HEAL_CIRCUIT_TRIP_COUNT || 3);
/** After OPEN, wait this long before half-open probe (prevents stuck open forever / re-notify storms). */
const CIRCUIT_HALF_OPEN_MS = Number(process.env.SELF_HEAL_CIRCUIT_HALF_OPEN_MS || 30 * 60 * 1000);
/** Cap safe auto-remediation attempts per error type per rolling day. */
const MAX_REMEDIATION_ATTEMPTS = Number(process.env.SELF_HEAL_MAX_REMEDIATION_ATTEMPTS || 2);
const REMEDIATION_ATTEMPT_WINDOW_MS = Number(
  process.env.SELF_HEAL_REMEDIATION_ATTEMPT_WINDOW_MS || 24 * 60 * 60 * 1000
);
const ENV_FINGERPRINT_DOC = 'env_drift_fingerprint';
const FORBIDDEN_SECRET_KEYS = Object.freeze([
  'STRIPE_API_KEY',
  'STRIPE_SECRET_KEY',
  'SECRET_STRIPE',
  'STRIPE_WEBHOOK_SECRET',
  'STRIPE_WEBHOOK_SECRET_LIVE',
  'BILIBILI_SESSDATA',
  'BILIBILI_BILI_JCT',
  'BILIBILI_DEDE_USER_ID',
  'RESEND_API_KEY',
  'EMAIL_API_KEY',
]);
const LOCAL_SECRET_FILES = Object.freeze(['.env.local', 'bilibili_secrets.env']);
const SITE_ORIGIN = 'https://resumora.net';
const DASHBOARD_URL = 'https://resumora.net/admin/system-health';
const PROBE_PATHS = ['/', '/pricing', '/login'];
const HEALTH_ALERT_THRESHOLD = Number(process.env.SELF_HEAL_ALERT_THRESHOLD || 70);
const HEALTH_ALERT_COOLDOWN_MS = Number(
  process.env.SELF_HEAL_ALERT_COOLDOWN_MS || 6 * 60 * 60 * 1000
);

/**
 * Gate for production project status:active sync (resumora.net catalog).
 * Skip when local env lacks admin passwords.
 * Allow only when NODE_ENV=production, or passwords are set AND explicitly opted in
 * (ALLOW_PROD_STATUS_SYNC=1). Local `npm run dev:all` must never PATCH production.
 */
function allowProductionStatusSync() {
  if (String(process.env.SKIP_PROD_STATUS_SYNC || '').trim() === '1') {
    return false;
  }
  const admin = Boolean(String(process.env.ADMIN_REFUND_PASSWORD || '').trim());
  const viteAdmin = Boolean(String(process.env.VITE_ADMIN_PASSWORD || '').trim());
  if (!admin && !viteAdmin) {
    return false;
  }
  const nodeEnv = String(process.env.NODE_ENV || '').toLowerCase();
  if (nodeEnv === 'production') {
    return true;
  }
  // Non-production: passwords alone are not enough (local .env often has them).
  return String(process.env.ALLOW_PROD_STATUS_SYNC || '').trim() === '1';
}

/**
 * Best-effort PATCH of production project status. No-op when gate fails.
 * Used by Cloud self-heal / ops only — never from local dev:all.
 */
async function syncProductionProjectStatus(status = 'active', { projectId = 'resumora' } = {}) {
  if (!allowProductionStatusSync()) {
    structuredLog('info', 'status_sync.skipped', {
      reason: 'local_or_missing_password_or_skip_flag',
      nodeEnv: process.env.NODE_ENV || null,
      hasAdminPassword: Boolean(String(process.env.ADMIN_REFUND_PASSWORD || '').trim()),
      hasViteAdminPassword: Boolean(String(process.env.VITE_ADMIN_PASSWORD || '').trim()),
    });
    return { ok: false, skipped: true, reason: 'status_sync_gated' };
  }
  const password = String(
    process.env.ADMIN_REFUND_PASSWORD || process.env.VITE_ADMIN_PASSWORD || ''
  ).trim();
  const base = String(process.env.RESUMORA_API_BASE || SITE_ORIGIN).replace(/\/$/, '');
  const url = `${base}/api/projects/${encodeURIComponent(projectId)}/status`;
  try {
    const res = await fetch(url, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        'x-admin-password': password,
        Authorization: `Bearer ${password}`,
      },
      body: JSON.stringify({
        projectId,
        status,
        source: 'self-heal',
      }),
      signal: AbortSignal.timeout(8000),
    });
    const body = await res.json().catch(() => ({}));
    if (!res.ok) {
      return { ok: false, skipped: false, status: res.status, error: body.error || res.statusText };
    }
    return { ok: true, skipped: false, status: body.status || status };
  } catch (err) {
    return {
      ok: false,
      skipped: false,
      error: String(err && err.message ? err.message : err).slice(0, 160),
    };
  }
}

const RISK = Object.freeze({
  SAFE: 'safe',
  CRITICAL: 'critical',
});

function timingSafeEqualString(a, b) {
  const left = Buffer.from(String(a || ''), 'utf8');
  const right = Buffer.from(String(b || ''), 'utf8');
  if (left.length !== right.length) return false;
  return crypto.timingSafeEqual(left, right);
}

function assertAdminPassword(req, expected) {
  const provided =
    req.get('x-admin-password') ||
    req.get('X-Admin-Password') ||
    (req.body && req.body.adminPassword) ||
    '';
  if (!expected || !timingSafeEqualString(provided, expected)) {
    const err = new Error('Unauthorized');
    err.statusCode = 401;
    throw err;
  }
}

function structuredLog(level, scope, payload) {
  const line = JSON.stringify({
    ts: new Date().toISOString(),
    scope: `selfHeal.${scope}`,
    ...(payload || {}),
  });
  if (level === 'error') console.error(line);
  else if (level === 'warn') console.warn(line);
  else console.log(line);
}

/** Prefix-only secret diagnostics — never full values. */
function secretShape(value, expectedPrefixes) {
  const v = String(value || '').trim();
  if (!v) return { present: false, ok: false, kind: 'missing', prefix: '(empty)' };
  const prefix = `${v.slice(0, Math.min(10, v.length))}...`;
  const matched = (expectedPrefixes || []).some((p) => v.startsWith(p));
  return {
    present: true,
    ok: matched,
    kind: matched ? 'expected_prefix' : 'unexpected_format',
    prefix,
    length: v.length,
  };
}

function priceShape(value) {
  const v = String(value || '').trim();
  if (!v) return { present: false, ok: false, prefix: '(empty)' };
  const ok = /^price_/.test(v);
  return { present: true, ok, prefix: ok ? 'price_…' : 'non_price' };
}

/**
 * Presence/shape fingerprint only — never includes secret values.
 * Used for preemptive drift detection without re-tripping every cycle.
 */
function envDriftFingerprint(env) {
  const e = env || {};
  return JSON.stringify({
    stripe: e.stripeSecret
      ? { present: e.stripeSecret.present, ok: e.stripeSecret.ok, kind: e.stripeSecret.kind }
      : null,
    webhook: e.webhookSecret
      ? { present: e.webhookSecret.present, ok: e.webhookSecret.ok, kind: e.webhookSecret.kind }
      : null,
    publishable: e.publishableKey
      ? { present: e.publishableKey.present, ok: e.publishableKey.ok, kind: e.publishableKey.kind }
      : null,
    prices: Object.fromEntries(
      Object.entries(e.prices || {}).map(([k, v]) => [k, { present: v.present, ok: v.ok }])
    ),
    resend: e.resend ? { present: e.resend.present, ok: e.resend.ok } : null,
    adminPasswordConfigured: Boolean(e.adminPasswordConfigured),
  });
}

async function loadEnvFingerprintState(db) {
  try {
    const snap = await db.collection(HEALTH_COL).doc(ENV_FINGERPRINT_DOC).get();
    if (!snap.exists) return { fingerprint: null, stableCycles: 0 };
    const data = snap.data() || {};
    return {
      fingerprint: data.fingerprint || null,
      stableCycles: Number(data.stableCycles || 0),
      lastChangedAt: data.lastChangedAt || null,
    };
  } catch (_) {
    return { fingerprint: null, stableCycles: 0 };
  }
}

async function saveEnvFingerprintState(db, fingerprint, previous) {
  const same = previous && previous.fingerprint === fingerprint;
  await db
    .collection(HEALTH_COL)
    .doc(ENV_FINGERPRINT_DOC)
    .set(
      {
        fingerprint,
        stableCycles: same ? Number(previous.stableCycles || 0) + 1 : 0,
        lastChangedAt: same
          ? previous.lastChangedAt || FieldValue.serverTimestamp()
          : FieldValue.serverTimestamp(),
        updatedAt: FieldValue.serverTimestamp(),
        note: 'Shape-only env inventory; no secret values stored.',
      },
      { merge: true }
    );
  return {
    fingerprint,
    changed: !same,
    stableCycles: same ? Number(previous.stableCycles || 0) + 1 : 0,
  };
}

function readEnvInventory() {
  const stripeSecret =
    process.env.STRIPE_API_KEY || process.env.STRIPE_SECRET_KEY || process.env.SECRET_STRIPE || '';
  const webhook = process.env.STRIPE_WEBHOOK_SECRET || process.env.STRIPE_WEBHOOK_SECRET_LIVE || '';
  const publishable =
    process.env.STRIPE_PUBLISHABLE_KEY ||
    process.env.VITE_STRIPE_PUBLISHABLE_KEY ||
    process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY ||
    '';

  const prices = {
    basic: process.env.STRIPE_PRICE_BASIC || process.env.VITE_STRIPE_PRICE_BASIC || '',
    balanced: process.env.STRIPE_PRICE_BALANCED || process.env.VITE_STRIPE_PRICE_BALANCED || '',
    professional:
      process.env.STRIPE_PRICE_PROFESSIONAL_TIER ||
      process.env.VITE_STRIPE_PRICE_PROFESSIONAL_TIER ||
      '',
    advanced: process.env.STRIPE_PRICE_ADVANCED || process.env.VITE_STRIPE_PRICE_ADVANCED || '',
  };

  const stripeSecretShape = secretShape(stripeSecret, ['sk_live_', 'sk_test_']);
  const liveMode = stripeSecretShape.ok && String(stripeSecret || '').startsWith('sk_live_');
  const checkoutSessionPrefix = resolveCheckoutSessionPrefix({ liveMode });

  return {
    stripeSecret: stripeSecretShape,
    webhookSecret: secretShape(webhook, ['whsec_']),
    publishableKey: secretShape(publishable, ['pk_live_', 'pk_test_']),
    prices: Object.fromEntries(Object.entries(prices).map(([k, v]) => [k, priceShape(v)])),
    resend: secretShape(process.env.RESEND_API_KEY || process.env.EMAIL_API_KEY || '', ['re_']),
    adminPasswordConfigured: Boolean(String(process.env.ADMIN_REFUND_PASSWORD || '').trim()),
    allowRestart: String(process.env.SELF_HEAL_ALLOW_RESTART || '').toLowerCase() === 'true',
    allowCdnPurge: String(process.env.SELF_HEAL_ALLOW_CDN_PURGE || '').toLowerCase() === 'true',
    checkoutSessionPrefix,
    liveMode,
  };
}

/**
 * Checkout session ID prefix — env override first, else derive from Stripe live/test mode.
 * Never hardcode only cs_live_ without reading CHECKOUT_SESSION_PREFIX.
 */
function resolveCheckoutSessionPrefix(opts = {}) {
  const fromEnv = String(process.env.CHECKOUT_SESSION_PREFIX || '')
    .trim()
    .toLowerCase();
  if (fromEnv === 'cs_live_' || fromEnv === 'cs_test_') return fromEnv;
  if (fromEnv.startsWith('cs_live')) return 'cs_live_';
  if (fromEnv.startsWith('cs_test')) return 'cs_test_';
  return opts.liveMode ? 'cs_live_' : 'cs_test_';
}

/**
 * Best-effort: reload local hermes-idea-queue after .env changes so Guardian sees fresh config.
 * No-op in Cloud Functions when HERMES_API_URL is unreachable.
 */
async function maybeRestartLocalQueue() {
  const base = String(process.env.HERMES_API_URL || 'http://127.0.0.1:8790').replace(/\/$/, '');
  try {
    const res = await fetch(`${base}/api/broc/reload-env`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reason: 'self-heal-env-refresh' }),
      signal: AbortSignal.timeout(8000),
    });
    if (!res.ok) {
      return { ok: false, status: res.status, skipped: false };
    }
    const data = await res.json().catch(() => ({}));
    return { ok: true, ...data };
  } catch (err) {
    return {
      ok: false,
      skipped: true,
      error: String(err && err.message ? err.message : err).slice(0, 160),
    };
  }
}

async function probeUrl(url, { method = 'GET', timeoutMs = 12000 } = {}) {
  const started = Date.now();
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      method,
      redirect: 'follow',
      signal: ctrl.signal,
      headers: { 'User-Agent': 'Resumora-SelfHeal/1.0' },
    });
    const latencyMs = Date.now() - started;
    return {
      url,
      method,
      ok: res.status >= 200 && res.status < 500,
      healthy: res.status >= 200 && res.status < 400,
      status: res.status,
      latencyMs,
    };
  } catch (err) {
    return {
      url,
      method,
      ok: false,
      healthy: false,
      status: 0,
      latencyMs: Date.now() - started,
      error: String(err && err.message ? err.message : err).slice(0, 160),
    };
  } finally {
    clearTimeout(timer);
  }
}

async function monitorHosting() {
  const results = [];
  for (const path of PROBE_PATHS) {
    results.push(await probeUrl(`${SITE_ORIGIN}${path}`));
  }
  results.push(await probeUrl(`${SITE_ORIGIN}/api/create-checkout-session`, { method: 'OPTIONS' }));
  return results;
}

async function monitorIamProbes() {
  const urls = [`${SITE_ORIGIN}/api/create-checkout-session`, `${SITE_ORIGIN}/api/video/catalog`];
  const results = [];
  for (const url of urls) {
    results.push(await probeUrl(url, { method: 'OPTIONS' }));
  }
  const blocked = results.filter((p) => p.status === 403 || p.status === 401);
  return {
    results,
    blocked: blocked.length > 0,
    blockedCount: blocked.length,
  };
}

/** Unacknowledged CRITICAL items from security_alerts (SCC / log sink → Firestore). */
async function monitorSecurityAlerts(db) {
  try {
    const snap = await db
      .collection('security_alerts')
      .where('severity', '==', 'CRITICAL')
      .where('acknowledged', '==', false)
      .limit(10)
      .get();
    return {
      ok: snap.empty,
      criticalCount: snap.size,
      ids: snap.docs.map((d) => d.id),
    };
  } catch (_) {
    return { ok: true, criticalCount: 0, skipped: true };
  }
}

async function monitorFirestore(db) {
  const started = Date.now();
  try {
    const ref = db.collection(HEALTH_COL).doc(HEALTH_DOC);
    await ref.set(
      {
        lastProbeAt: FieldValue.serverTimestamp(),
        knowledgeHeartbeat: true,
      },
      { merge: true }
    );
    const snap = await ref.get();
    return {
      ok: snap.exists,
      latencyMs: Date.now() - started,
    };
  } catch (err) {
    return {
      ok: false,
      latencyMs: Date.now() - started,
      error: String(err && err.message ? err.message : err).slice(0, 160),
    };
  }
}

async function monitorStripe(stripe) {
  if (!stripe) {
    return { ok: false, reason: 'stripe_client_missing', latencyMs: null };
  }
  const started = Date.now();
  try {
    const list = await stripe.prices.list({ limit: 1, active: true });
    const first = list && list.data && list.data[0];
    return {
      ok: true,
      latencyMs: Date.now() - started,
      // Never log full price_ IDs
      samplePricePresent: Boolean(first && first.id && String(first.id).startsWith('price_')),
    };
  } catch (err) {
    return {
      ok: false,
      latencyMs: Date.now() - started,
      error: String(err && err.message ? err.message : err).slice(0, 160),
    };
  }
}

/** Analyze: score + RCA findings (keys for i18n on the dashboard). */
function analyze(observations) {
  const findings = [];
  let score = 100;
  const hosting = observations.hosting || [];
  const slow = hosting.filter((p) => p.latencyMs > 4000);
  const down = hosting.filter((p) => !p.healthy);

  for (const p of down) {
    findings.push({
      code: 'hosting_probe_failed',
      severity: 'high',
      detail: { path: p.url, status: p.status, error: p.error || null },
      rcaKey: 'heal.rca.hostingDown',
    });
    score -= 25;
  }
  for (const p of slow) {
    findings.push({
      code: 'hosting_high_latency',
      severity: 'medium',
      detail: { path: p.url, latencyMs: p.latencyMs },
      rcaKey: 'heal.rca.highLatency',
    });
    score -= 8;
  }

  const env = observations.env || {};
  if (!env.stripeSecret || !env.stripeSecret.ok) {
    findings.push({
      code: 'env_stripe_secret_drift',
      severity: 'critical',
      detail: { kind: env.stripeSecret && env.stripeSecret.kind },
      rcaKey: 'heal.rca.envStripeSecret',
      risk: RISK.CRITICAL,
    });
    score -= 30;
  }
  if (!env.webhookSecret || !env.webhookSecret.ok) {
    findings.push({
      code: 'env_webhook_drift',
      severity: 'critical',
      detail: { kind: env.webhookSecret && env.webhookSecret.kind },
      rcaKey: 'heal.rca.envWebhook',
      risk: RISK.CRITICAL,
    });
    score -= 20;
  }
  const priceFail = Object.entries(env.prices || {}).filter(([, v]) => !v.ok);
  if (priceFail.length) {
    findings.push({
      code: 'env_price_drift',
      severity: 'high',
      detail: { plans: priceFail.map(([k]) => k) },
      rcaKey: 'heal.rca.envPrices',
      risk: RISK.CRITICAL,
    });
    score -= 10 * priceFail.length;
  }

  if (observations.firestore && !observations.firestore.ok) {
    findings.push({
      code: 'firestore_unreachable',
      severity: 'critical',
      detail: { error: observations.firestore.error || null },
      rcaKey: 'heal.rca.firestore',
      risk: RISK.CRITICAL,
    });
    score -= 35;
  }

  if (observations.stripe && !observations.stripe.ok) {
    findings.push({
      code: 'stripe_api_unhealthy',
      severity: 'high',
      detail: { error: observations.stripe.error || observations.stripe.reason || null },
      rcaKey: 'heal.rca.stripeApi',
    });
    score -= 20;
  }

  const checkoutPrefix = String(
    (observations.env && observations.env.checkoutSessionPrefix) ||
      resolveCheckoutSessionPrefix({
        liveMode: Boolean(observations.env && observations.env.liveMode),
      })
  );
  if (checkoutPrefix !== 'cs_live_' && checkoutPrefix !== 'cs_test_') {
    findings.push({
      code: 'checkout_prefix_invalid',
      severity: 'medium',
      detail: { checkoutSessionPrefix: checkoutPrefix },
      rcaKey: 'heal.rca.checkoutPrefix',
    });
    score -= 5;
  }

  if (observations.iam && observations.iam.blocked) {
    findings.push({
      code: 'iam_policy_block',
      severity: 'high',
      detail: { blockedCount: observations.iam.blockedCount },
      rcaKey: 'heal.rca.iamBlock',
      risk: RISK.CRITICAL,
    });
    score -= 15;
  }

  if (observations.security && observations.security.criticalCount > 0) {
    findings.push({
      code: 'scc_critical_finding',
      severity: 'critical',
      detail: {
        criticalCount: observations.security.criticalCount,
        alertIds: observations.security.ids || [],
      },
      rcaKey: 'heal.rca.sccCritical',
      risk: RISK.CRITICAL,
    });
    score -= 25;
  }

  score = Math.max(0, Math.min(100, score));
  const status =
    score >= 90 ? 'healthy' : score >= 70 ? 'degraded' : score >= 40 ? 'impaired' : 'critical';

  return { score, status, findings };
}

/**
 * Dynamic operator checklist from live findings + Guardian gates.
 * Never includes secret values — key names and runbook commands only.
 */
function buildNextChecklist({ findings = [], guardian = null, score = null } = {}) {
  const codes = [...new Set((findings || []).map((f) => f && f.code).filter(Boolean))];
  const checks = (guardian && guardian.checks) || {};
  const guardianFailed = guardian && guardian.passed === false;
  const region = String(process.env.GCP_REGION || process.env.FUNCTION_REGION || 'us-central1');
  const service = String(
    process.env.HEALTH_CHECKLIST_SERVICE || process.env.K_SERVICE || 'getsystemhealth'
  );
  const project = String(
    process.env.GCLOUD_PROJECT || process.env.GCP_PROJECT || 'YOUR_GCP_PROJECT'
  );

  const playbooks = {
    env_stripe_secret_drift: {
      id: 'stripe_secret',
      priority: 10,
      hitl: true,
      title: 'Fix Stripe secret shape (HITL)',
      points: 30,
      envKeys: ['STRIPE_SECRET_KEY', 'SECRET_STRIPE', 'STRIPE_API_KEY'],
      iam: [
        'roles/secretmanager.secretAccessor on runtime service account',
        'Secret Manager secret version mounted as STRIPE_SECRET_KEY',
      ],
      commands: [
        `gcloud run services update ${service} --project=${project} --region=${region} --update-secrets=STRIPE_SECRET_KEY=STRIPE_SECRET_KEY:latest`,
      ],
      steps: [
        'Confirm Secret Manager has a live key starting with sk_live_ (or sk_test_ in test).',
        'Mount it on the Cloud Run / Functions service as STRIPE_SECRET_KEY.',
        'Redeploy via git push → GitHub Actions (do not firebase deploy locally).',
        'Run System Health once.',
      ],
    },
    env_webhook_drift: {
      id: 'webhook_secret',
      priority: 20,
      hitl: true,
      title: 'Fix Stripe webhook secret (HITL)',
      points: 20,
      envKeys: ['STRIPE_WEBHOOK_SECRET', 'STRIPE_WEBHOOK_SECRET_LIVE'],
      iam: ['roles/secretmanager.secretAccessor on stripeWebhook / resumora-checkout SA'],
      commands: [
        `gcloud run services update ${service} --project=${project} --region=${region} --update-secrets=STRIPE_WEBHOOK_SECRET=STRIPE_WEBHOOK_SECRET:latest`,
      ],
      steps: [
        'Copy webhook signing secret from Stripe Dashboard (whsec_…).',
        'Store in Secret Manager; mount as STRIPE_WEBHOOK_SECRET.',
        'Ensure stripeWebhook function uses the same secret.',
        'Run System Health once.',
      ],
    },
    env_price_drift: {
      id: 'price_ids',
      priority: 30,
      hitl: true,
      title: 'Set plan price env vars (HITL)',
      points: 10,
      envKeys: [
        'STRIPE_PRICE_BASIC',
        'STRIPE_PRICE_BALANCED',
        'STRIPE_PRICE_PROFESSIONAL_TIER',
        'STRIPE_PRICE_ADVANCED',
      ],
      iam: [],
      commands: [
        `gcloud run services update ${service} --project=${project} --region=${region} --update-env-vars=STRIPE_PRICE_BASIC=price_REPLACE,STRIPE_PRICE_BALANCED=price_REPLACE,STRIPE_PRICE_PROFESSIONAL_TIER=price_REPLACE,STRIPE_PRICE_ADVANCED=price_REPLACE`,
      ],
      steps: [
        'Set all four STRIPE_PRICE_* to live price_… IDs (−10 score each if missing).',
        'Prefer Secret Manager or CI-injected env — never commit values.',
        'Run System Health once.',
      ],
    },
    stripe_api_unhealthy: {
      id: 'stripe_api',
      priority: 25,
      hitl: true,
      title: 'Repair Stripe API client (HITL)',
      points: 20,
      envKeys: ['STRIPE_SECRET_KEY'],
      iam: ['Secret mounted and readable by Cloud Run runtime SA'],
      commands: [
        `gcloud run services update ${service} --project=${project} --region=${region} --update-secrets=STRIPE_SECRET_KEY=STRIPE_SECRET_KEY:latest`,
      ],
      steps: [
        'Verify STRIPE_SECRET_KEY is present in the running revision (shape only).',
        'If secret was rotated, update Secret Manager version and redeploy.',
        'Confirm prices.list succeeds after heal.',
      ],
    },
    checkout_prefix_invalid: {
      id: 'checkout_prefix',
      priority: 40,
      hitl: false,
      title: 'Set CHECKOUT_SESSION_PREFIX',
      points: 5,
      envKeys: ['CHECKOUT_SESSION_PREFIX'],
      iam: [],
      commands: [
        `gcloud run services update ${service} --project=${project} --region=${region} --update-env-vars=CHECKOUT_SESSION_PREFIX=cs_live_`,
      ],
      steps: [
        'Set CHECKOUT_SESSION_PREFIX=cs_live_ on Cloud Run (and local .env for Hermes reload).',
        'Run System Health once — Guardian checkoutPrefixOk should pass.',
      ],
    },
    firestore_unreachable: {
      id: 'firestore',
      priority: 15,
      hitl: true,
      title: 'Restore Firestore access (HITL)',
      points: 35,
      envKeys: ['GCLOUD_PROJECT', 'GCP_PROJECT'],
      iam: [
        'roles/datastore.user (or Firestore equivalent) on Functions runtime SA',
        'No org policy blocking Firestore Admin SDK writes',
      ],
      commands: [
        `gcloud projects add-iam-policy-binding ${project} --member=serviceAccount:RUNTIME_SA@${project}.iam.gserviceaccount.com --role=roles/datastore.user`,
      ],
      steps: [
        'Confirm system_health/current can be written by the Functions SA.',
        'Grant datastore/Firestore roles if missing; redeploy Functions.',
        'Run System Health once.',
      ],
    },
    iam_policy_block: {
      id: 'iam_invoker',
      priority: 35,
      hitl: true,
      title: 'Fix public API invoker IAM (HITL)',
      points: 15,
      envKeys: [],
      iam: [
        'roles/run.invoker for allUsers (or load balancer) on create-checkout-session',
        'Allow OPTIONS/POST on /api/create-checkout-session and /api/video/catalog',
      ],
      commands: [
        `gcloud run services add-iam-policy-binding ${service} --project=${project} --region=${region} --member=allUsers --role=roles/run.invoker`,
      ],
      steps: [
        'Public checkout must not return 401/403 on OPTIONS.',
        'Apply invoker binding carefully (org policy may block allUsers — use LB identity if required).',
        'Run System Health once.',
      ],
    },
    hosting_probe_failed: {
      id: 'hosting_down',
      priority: 45,
      hitl: true,
      title: 'Restore Firebase Hosting probes',
      points: 25,
      envKeys: [],
      iam: [],
      commands: [
        'git push origin main  # triggers Deploy Firebase Hosting Production (do not firebase deploy locally)',
      ],
      steps: [
        'Confirm https://resumora.net/, /pricing, /login return 2xx/3xx.',
        'Approve pending CDN purge HITL ticket if present, then redeploy via GHA.',
        'Safe auto-heal may warmup; re-run heal once.',
      ],
    },
    hosting_high_latency: {
      id: 'hosting_latency',
      priority: 50,
      hitl: false,
      title: 'Warm cold Hosting paths',
      points: 8,
      envKeys: [],
      iam: [],
      commands: [],
      steps: [
        'Click Run system heal once (allowlisted warmup_endpoints).',
        'If still >4s, check Firebase Hosting / CDN — not Vercel.',
      ],
    },
    scc_critical_finding: {
      id: 'scc',
      priority: 18,
      hitl: true,
      title: 'Acknowledge SCC CRITICAL alerts (HITL)',
      points: 25,
      envKeys: [],
      iam: ['Security Command Center viewer (optional) for root cause'],
      commands: [],
      steps: [
        'Open Firestore security_alerts where severity=CRITICAL and acknowledged=false.',
        'Fix the underlying issue, then set acknowledged=true.',
        'Run System Health once (−25 returns when none remain).',
      ],
    },
  };

  const items = [];
  for (const code of codes) {
    const pb = playbooks[code];
    if (!pb) {
      items.push({
        id: code,
        code,
        priority: 90,
        hitl: true,
        title: `Review finding: ${code}`,
        points: null,
        envKeys: [],
        iam: [],
        commands: [],
        steps: [
          'Open Findings on System Health and follow the RCA text.',
          'Run heal once after fix.',
        ],
      });
      continue;
    }
    items.push({ ...pb, code });
  }

  // Guardian-only gaps (score may already include finding, but surface failed gates explicitly)
  if (guardianFailed) {
    const gateMap = [
      ['envStripeOk', 'env_stripe_secret_drift'],
      ['envWebhookOk', 'env_webhook_drift'],
      ['stripeOk', 'stripe_api_unhealthy'],
      ['firestoreOk', 'firestore_unreachable'],
      ['hostingOk', 'hosting_probe_failed'],
      ['checkoutPrefixOk', 'checkout_prefix_invalid'],
    ];
    for (const [gate, code] of gateMap) {
      if (checks[gate] === false && !codes.includes(code) && playbooks[code]) {
        items.push({ ...playbooks[code], code, fromGuardian: true });
      }
    }
  }

  items.sort((a, b) => (a.priority || 99) - (b.priority || 99));

  const envKeys = [...new Set(items.flatMap((i) => i.envKeys || []))];
  const hitlGates = items.filter((i) => i.hitl).map((i) => i.id);
  const pointsAtStake = items.reduce((sum, i) => sum + (Number(i.points) || 0), 0);
  const nScore = Number(score);
  const gap = Number.isFinite(nScore) ? Math.max(0, 100 - nScore) : null;

  return {
    generatedAt: new Date().toISOString(),
    score: Number.isFinite(nScore) ? nScore : null,
    gapTo100: gap,
    pointsAtStake,
    hitlRequired: hitlGates.length > 0,
    hitlGates: [...new Set(hitlGates)],
    findingCodes: codes,
    guardianPassed: guardian ? Boolean(guardian.passed) : null,
    failedGuardianGates: Object.entries(checks)
      .filter(([k, v]) => k.endsWith('Ok') && v === false)
      .map(([k]) => k),
    envKeys,
    service,
    region,
    projectHint: project,
    items,
    note: 'Safe auto-heal is warmup only. Secrets, prices, IAM, SCC, and deploys require human ops. Never use Vercel for resumora.net.',
  };
}

function mapFindingToErrorType(code) {
  const table = {
    hosting_probe_failed: 'HOSTING_PROBE',
    hosting_high_latency: 'HOSTING_LATENCY',
    env_stripe_secret_drift: 'ENV_SECRET_DRIFT',
    env_webhook_drift: 'STRIPE_WEBHOOK_DRIFT',
    env_price_drift: 'ENV_PRICE_DRIFT',
    firestore_unreachable: 'FIRESTORE',
    stripe_api_unhealthy: 'STRIPE_API',
    iam_policy_block: 'IAM_POLICY_BLOCK',
    scc_critical_finding: 'SCC_CRITICAL',
  };
  return table[code] || String(code || 'UNKNOWN').toUpperCase();
}

function circuitDocId(errorType) {
  return String(errorType || 'UNKNOWN')
    .replace(/[^A-Z0-9_]/gi, '_')
    .slice(0, 80);
}

/**
 * Guardrail: refuse any auto-fix that would mutate secrets, local env files, or IAM.
 * Returns { ok, reason, requiresHuman }.
 */
function preDamageCheck(action, analysis) {
  const id = String(action && action.id ? action.id : '');
  const codes = new Set((analysis.findings || []).map((f) => f.code));

  if (LOCAL_SECRET_FILES.some((f) => id.includes(f) || String(action.reason || '').includes(f))) {
    return { ok: false, requiresHuman: true, reason: 'local_secret_file_guard' };
  }

  const secretFindings = ['env_stripe_secret_drift', 'env_webhook_drift', 'env_price_drift'];
  if (secretFindings.some((c) => codes.has(c))) {
    return { ok: false, requiresHuman: true, reason: 'secret_or_price_env_requires_human' };
  }

  if (codes.has('iam_policy_block')) {
    return { ok: false, requiresHuman: true, reason: 'iam_policy_requires_human' };
  }

  const envKeysTouched = String(action.reason || '') + String(id);
  if (FORBIDDEN_SECRET_KEYS.some((k) => envKeysTouched.includes(k))) {
    return { ok: false, requiresHuman: true, reason: 'forbidden_secret_key_name' };
  }

  const forbiddenIds = new Set([
    'env_rollback_proposal',
    'cloud_run_restart_proposal',
    'cdn_purge_proposal',
    'secret_rewrite',
    'gcloud_iam_bypass',
    'firebase_deploy',
  ]);
  if (forbiddenIds.has(id) || action.risk === RISK.CRITICAL) {
    return { ok: false, requiresHuman: true, reason: 'critical_or_forbidden_action' };
  }

  // SAFE allowlist only
  const allowed = new Set(['warmup_endpoints', 'record_only', 'first_time_warmup_verify']);
  if (!allowed.has(id)) {
    return { ok: false, requiresHuman: true, reason: 'action_not_in_safe_allowlist' };
  }

  return { ok: true, requiresHuman: false, reason: 'allowlisted_safe' };
}

async function recordErrorOccurrence(db, errorType, cycleId) {
  const id = circuitDocId(errorType);
  const ref = db.collection(CIRCUIT_COL).doc(id);
  const now = Date.now();
  const windowStart = now - CIRCUIT_WINDOW_MS;

  return db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    const data = snap.exists ? snap.data() || {} : {};
    let open = data.state === 'open' || data.paused === true;

    // Half-open: after cool-down, allow one observation window instead of permanent flap/open.
    if (open) {
      let openedMs = 0;
      if (data.openedAt && typeof data.openedAt.toDate === 'function') {
        openedMs = data.openedAt.toDate().getTime();
      } else if (typeof data.openedAtMs === 'number') {
        openedMs = data.openedAtMs;
      }
      const age = openedMs ? now - openedMs : 0;
      if (age >= CIRCUIT_HALF_OPEN_MS) {
        tx.set(
          ref,
          {
            errorType,
            state: 'half_open',
            paused: false,
            hits: [now],
            countInWindow: 1,
            windowMs: CIRCUIT_WINDOW_MS,
            tripCount: CIRCUIT_TRIP_COUNT,
            halfOpenAt: FieldValue.serverTimestamp(),
            lastCycleId: cycleId,
            updatedAt: FieldValue.serverTimestamp(),
          },
          { merge: true }
        );
        return {
          errorType,
          state: 'half_open',
          count: 1,
          tripped: false,
          alreadyOpen: false,
          halfOpen: true,
        };
      }
      return {
        errorType,
        state: 'open',
        count: Number(data.countInWindow || 0),
        tripped: true,
        alreadyOpen: true,
        remediationAttempts: Number(data.remediationAttempts || 0),
      };
    }

    const hits = Array.isArray(data.hits) ? data.hits.filter((h) => Number(h) >= windowStart) : [];
    hits.push(now);
    const count = hits.length;
    const shouldTrip = count >= CIRCUIT_TRIP_COUNT;
    const next = {
      errorType,
      hits,
      countInWindow: count,
      windowMs: CIRCUIT_WINDOW_MS,
      tripCount: CIRCUIT_TRIP_COUNT,
      halfOpenMs: CIRCUIT_HALF_OPEN_MS,
      maxRemediationAttempts: MAX_REMEDIATION_ATTEMPTS,
      remediationAttempts: Number(data.remediationAttempts || 0),
      state: shouldTrip ? 'open' : data.state === 'half_open' && !shouldTrip ? 'closed' : 'closed',
      paused: shouldTrip,
      requiresHumanReview: shouldTrip,
      lastCycleId: cycleId,
      lastHitAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp(),
    };
    if (shouldTrip) {
      next.openedAt = FieldValue.serverTimestamp();
      next.openedAtMs = now;
      next.openReason = `${count}_hits_in_${CIRCUIT_WINDOW_MS}ms`;
    }
    tx.set(ref, next, { merge: true });
    return {
      errorType,
      state: next.state,
      count,
      tripped: shouldTrip,
      alreadyOpen: false,
      remediationAttempts: next.remediationAttempts,
    };
  });
}

async function canAttemptRemediation(db, errorType) {
  const id = circuitDocId(errorType);
  try {
    const snap = await db.collection(CIRCUIT_COL).doc(id).get();
    if (!snap.exists) return { ok: true, attempts: 0 };
    const data = snap.data() || {};
    const attempts = Number(data.remediationAttempts || 0);
    let lastMs = 0;
    if (data.lastRemediationAt && typeof data.lastRemediationAt.toDate === 'function') {
      lastMs = data.lastRemediationAt.toDate().getTime();
    }
    if (lastMs && Date.now() - lastMs > REMEDIATION_ATTEMPT_WINDOW_MS) {
      return { ok: true, attempts: 0, resetWindow: true };
    }
    if (attempts >= MAX_REMEDIATION_ATTEMPTS) {
      return { ok: false, attempts, reason: 'remediation_attempts_exhausted' };
    }
    return { ok: true, attempts };
  } catch (_) {
    return { ok: true, attempts: 0 };
  }
}

async function bumpRemediationAttempts(db, errorType, cycleId) {
  const id = circuitDocId(errorType);
  const ref = db.collection(CIRCUIT_COL).doc(id);
  await db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    const data = snap.exists ? snap.data() || {} : {};
    let attempts = Number(data.remediationAttempts || 0);
    let lastMs = 0;
    if (data.lastRemediationAt && typeof data.lastRemediationAt.toDate === 'function') {
      lastMs = data.lastRemediationAt.toDate().getTime();
    }
    if (lastMs && Date.now() - lastMs > REMEDIATION_ATTEMPT_WINDOW_MS) {
      attempts = 0;
    }
    tx.set(
      ref,
      {
        errorType,
        remediationAttempts: attempts + 1,
        lastRemediationAt: FieldValue.serverTimestamp(),
        lastRemediationCycleId: cycleId,
        updatedAt: FieldValue.serverTimestamp(),
      },
      { merge: true }
    );
  });
}

async function findPendingApproval(db, actionId) {
  try {
    const q = await db
      .collection(APPROVALS_COL)
      .where('actionId', '==', String(actionId || ''))
      .where('status', '==', 'pending_approval')
      .limit(1)
      .get();
    if (!q.empty) {
      const d = q.docs[0];
      return { id: d.id, ...(d.data() || {}) };
    }
  } catch (_) {
    /* composite index may be missing — fall through */
  }
  return null;
}

async function listOpenCircuits(db) {
  try {
    const q = await db.collection(CIRCUIT_COL).where('state', '==', 'open').limit(40).get();
    return q.docs.map((d) => ({ id: d.id, ...(d.data() || {}) }));
  } catch (_) {
    const q = await db.collection(CIRCUIT_COL).limit(40).get();
    return q.docs
      .map((d) => ({ id: d.id, ...(d.data() || {}) }))
      .filter((d) => d.state === 'open' || d.paused);
  }
}

async function resetCircuitsIfHealthy(db, analysis) {
  if (!analysis || analysis.score < 100 || (analysis.findings || []).length) return { reset: [] };
  const open = await listOpenCircuits(db);
  const reset = [];
  for (const c of open) {
    await db.collection(CIRCUIT_COL).doc(c.id).set(
      {
        state: 'closed',
        paused: false,
        requiresHumanReview: false,
        hits: [],
        countInWindow: 0,
        closedAt: FieldValue.serverTimestamp(),
        closedReason: 'health_score_100',
        updatedAt: FieldValue.serverTimestamp(),
      },
      { merge: true }
    );
    reset.push(c.errorType || c.id);
  }
  return { reset };
}

async function freezeCircuit(db, errorType, reason, cycleId) {
  const id = circuitDocId(errorType);
  await db
    .collection(CIRCUIT_COL)
    .doc(id)
    .set(
      {
        errorType,
        state: 'open',
        paused: true,
        requiresHumanReview: true,
        lastCycleId: cycleId,
        freezeReason: String(reason || 'verification_failed').slice(0, 200),
        openedAt: FieldValue.serverTimestamp(),
        updatedAt: FieldValue.serverTimestamp(),
      },
      { merge: true }
    );
}

/**
 * First-time auto-fix: warmup + HTTP verify only.
 * Does not run gcloud/firebase deploy (those mutate IAM/secrets and require HITL).
 */
async function autoRemediateFirstTime(db, { errorType, cycleId, analysis }) {
  const firstRef = db.collection(FIRST_FIX_COL).doc(circuitDocId(errorType));
  const firstSnap = await firstRef.get();
  const alreadyTried = firstSnap.exists && firstSnap.data()?.status === 'remediated';

  const guard = preDamageCheck(
    { id: 'first_time_warmup_verify', risk: RISK.SAFE, reason: 'first_time_auto_fix' },
    analysis
  );
  if (!guard.ok) {
    return {
      skipped: true,
      reason: guard.reason,
      requiresHuman: true,
      errorType,
    };
  }

  if (alreadyTried) {
    return { skipped: true, reason: 'already_first_timed', errorType };
  }

  const attemptGate = await canAttemptRemediation(db, errorType);
  if (!attemptGate.ok) {
    return {
      skipped: true,
      reason: attemptGate.reason || 'remediation_attempts_exhausted',
      requiresHuman: true,
      errorType,
      remediationAttempts: attemptGate.attempts,
    };
  }

  await bumpRemediationAttempts(db, errorType, cycleId);

  const before = await monitorHosting();
  const warmup = await executeWarmup();
  const after = await monitorHosting();
  const verified = after.every((p) => p.healthy);

  const record = {
    errorType,
    cycleId,
    status: verified ? 'remediated' : 'verification_failed',
    warmupOk: Boolean(warmup.ok),
    verified,
    beforeStatuses: before.map((p) => p.status),
    afterStatuses: after.map((p) => p.status),
    note: 'Safe first-time fix is HTTP warmup only. gcloud IAM / firebase deploy remain HITL.',
    updatedAt: FieldValue.serverTimestamp(),
  };
  await firstRef.set(record, { merge: true });

  await writeRemediation(db, {
    cycleId,
    actionId: 'first_time_warmup_verify',
    errorType,
    risk: RISK.SAFE,
    status: verified ? 'applied' : 'verification_failed',
    result: { warmup, verified },
    titleKey: 'heal.action.firstTime',
  });

  if (!verified) {
    await freezeCircuit(db, errorType, 'first_time_verify_failed', cycleId);
    await createApproval(
      db,
      {
        id: 'auto_rollback_proposal',
        titleKey: 'heal.action.rollback',
        reason: `First-time auto-fix verification failed for ${errorType} — freeze + human rollback`,
      },
      analysis,
      cycleId
    );
  }

  return { skipped: false, verified, errorType, warmup };
}

function planRemediations(analysis) {
  const actions = [];
  const codes = new Set((analysis.findings || []).map((f) => f.code));

  if (codes.has('hosting_probe_failed') || codes.has('hosting_high_latency')) {
    actions.push({
      id: 'warmup_endpoints',
      risk: RISK.SAFE,
      titleKey: 'heal.action.warmup',
      reason: 'Reflexion: retry cold paths after failed/slow probes',
    });
  }

  if (codes.has('hosting_probe_failed')) {
    actions.push({
      id: 'cdn_purge_proposal',
      risk: RISK.CRITICAL,
      titleKey: 'heal.action.cdnPurge',
      reason: 'Hosting may be serving stale HTML — requires human-approved purge/redeploy',
    });
  }

  if (codes.has('stripe_api_unhealthy') || codes.has('env_stripe_secret_drift')) {
    actions.push({
      id: 'cloud_run_restart_proposal',
      risk: RISK.CRITICAL,
      titleKey: 'heal.action.restart',
      reason: 'Stuck Cloud Run / bad secret injection — restart needs approval',
    });
  }

  if (
    codes.has('env_stripe_secret_drift') ||
    codes.has('env_webhook_drift') ||
    codes.has('env_price_drift')
  ) {
    actions.push({
      id: 'env_rollback_proposal',
      risk: RISK.CRITICAL,
      titleKey: 'heal.action.envRollback',
      reason: 'Env drift detected — Git rollback / secret rotation requires approval',
    });
  }

  if (!actions.length && analysis.score < 100) {
    actions.push({
      id: 'record_only',
      risk: RISK.SAFE,
      titleKey: 'heal.action.record',
      reason: 'No safe auto-fix; knowledge base updated',
    });
  }

  return actions;
}

async function sendAdminNotify({ subject, text, html }) {
  const apiKey = String(process.env.RESEND_API_KEY || process.env.EMAIL_API_KEY || '').trim();
  const to =
    String(
      process.env.SELF_HEAL_ADMIN_EMAIL || process.env.ADMIN_NOTIFY_EMAIL || 'info@resumora.net'
    ).trim() || 'info@resumora.net';
  const from =
    String(process.env.SELF_HEAL_EMAIL_FROM || process.env.REFUND_EMAIL_FROM || '').trim() ||
    'Resumora Self-Heal <onboarding@resend.dev>';

  const slackUrl = String(
    process.env.SELF_HEAL_SLACK_WEBHOOK || process.env.SLACK_WEBHOOK_URL || ''
  ).trim();
  if (slackUrl) {
    try {
      await fetch(slackUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: `${subject}\n${text}` }),
      });
    } catch (err) {
      structuredLog('warn', 'slack', { error: String(err.message || err).slice(0, 120) });
    }
  }

  if (!apiKey) {
    structuredLog('warn', 'notify', { skipped: true, hasKey: false, hasTo: Boolean(to) });
    return { skipped: true };
  }

  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ from, to: [to], subject, text, html: html || undefined }),
  });
  if (!res.ok) {
    structuredLog('error', 'notify', { status: res.status });
    return { ok: false, status: res.status };
  }
  return { ok: true };
}

async function notificationCooldownAllows(db, key, cooldownMs) {
  const snap = await db.collection(NOTIFY_COL).doc(key).get();
  if (!snap.exists) return true;
  const last = snap.data()?.lastSentAt;
  if (!last || typeof last.toDate !== 'function') return true;
  return Date.now() - last.toDate().getTime() >= cooldownMs;
}

async function recordNotification(db, key, payload) {
  await db
    .collection(NOTIFY_COL)
    .doc(key)
    .set(
      {
        key,
        ...payload,
        lastSentAt: FieldValue.serverTimestamp(),
        updatedAt: FieldValue.serverTimestamp(),
      },
      { merge: true }
    );
}

/**
 * Real-time alert when score &lt; threshold or Guardian fails after remediation.
 * Deduped via notification_history.
 */
async function maybeSendHealthAlert(db, { cycleId, analysis, guardian, incidentId }) {
  const threshold = Number.isFinite(HEALTH_ALERT_THRESHOLD) ? HEALTH_ALERT_THRESHOLD : 70;
  const scoreLow = analysis.score < threshold;
  const guardianFail = guardian && guardian.passed === false;
  if (!scoreLow && !guardianFail) {
    if (analysis.score >= threshold) {
      await db.collection(NOTIFY_COL).doc('health_score_low').set(
        {
          key: 'health_score_low',
          resolved: true,
          resolvedAt: FieldValue.serverTimestamp(),
          lastScore: analysis.score,
        },
        { merge: true }
      );
    }
    return { sent: false };
  }

  const key = scoreLow ? 'health_score_low' : 'health_guardian_fail';
  if (!(await notificationCooldownAllows(db, key, HEALTH_ALERT_COOLDOWN_MS))) {
    structuredLog('info', 'alert.suppressed', { key, score: analysis.score });
    return { sent: false, suppressed: true };
  }

  const when = new Date().toISOString();
  const findings = (analysis.findings || [])
    .slice(0, 8)
    .map((f) => `- ${f.code} (${f.severity || 'info'})`)
    .join('\n');
  const subject = `[Resumora] System health ${analysis.status} — score ${analysis.score}`;
  const text = [
    'System health alert (MAPE-K self-heal).',
    '',
    `Time: ${when}`,
    `Cycle: ${cycleId}`,
    `Score: ${analysis.score} / threshold ${threshold}`,
    `Status: ${analysis.status}`,
    `Guardian passed: ${guardian && guardian.passed ? 'yes' : 'no'}`,
    `Incident: ${incidentId || '—'}`,
    '',
    'Findings:',
    findings || '- (none)',
    '',
    `Dashboard: ${DASHBOARD_URL}`,
    '',
    'FR: Alerte santé système — ouvrez le tableau de bord.',
    'ES: Alerta de salud del sistema — abra el panel.',
  ].join('\n');

  await sendAdminNotify({ subject, text });
  await recordNotification(db, key, {
    type: key,
    subject,
    score: analysis.score,
    status: analysis.status,
    cycleId,
    incidentId: incidentId || null,
    resolved: false,
    dashboardUrl: DASHBOARD_URL,
  });
  // Also append an auto-id history row for audit trail
  await db.collection(NOTIFY_COL).add({
    key,
    type: key,
    subject,
    score: analysis.score,
    cycleId,
    createdAt: FieldValue.serverTimestamp(),
  });

  structuredLog('warn', 'alert.sent', { key, score: analysis.score });
  return { sent: true, key };
}

async function createApproval(db, action, analysis, cycleId) {
  const existing = await findPendingApproval(db, action.id);
  if (existing) {
    structuredLog('info', 'approval.deduped', {
      actionId: action.id,
      existingId: existing.id,
      cycleId,
    });
    return { id: existing.id, ...existing, deduped: true };
  }

  const ref = db.collection(APPROVALS_COL).doc();
  const doc = {
    id: ref.id,
    cycleId,
    actionId: action.id,
    titleKey: action.titleKey,
    reason: action.reason,
    risk: RISK.CRITICAL,
    status: 'pending_approval',
    analysisScore: analysis.score,
    analysisStatus: analysis.status,
    findingCodes: (analysis.findings || []).map((f) => f.code),
    createdAt: FieldValue.serverTimestamp(),
    localeMessages: {
      en: `Approval required: ${action.id} — ${action.reason}`,
      fr: `Approbation requise: ${action.id} — ${action.reason}`,
      es: `Aprobación requerida: ${action.id} — ${action.reason}`,
    },
  };
  await ref.set(doc);
  await sendAdminNotify({
    subject: `[Resumora Self-Heal] Approval required — ${action.id}`,
    text: [
      'A critical remediation was planned but NOT applied.',
      '',
      `Approval ID: ${ref.id}`,
      `Action: ${action.id}`,
      `Reason: ${action.reason}`,
      `Health score: ${analysis.score} (${analysis.status})`,
      '',
      `Dashboard: ${DASHBOARD_URL}`,
      'Approve via /admin/system-health or POST /api/admin/system-health/decide',
      'FR: Une correction critique nécessite votre approbation.',
      'ES: Una corrección crítica requiere su aprobación.',
    ].join('\n'),
  });

  // Zero-touch: auto-authorize all heal tickets when gate is on (still does not rewrite secrets).
  if (isAutoAckEnabled()) {
    try {
      await decideApproval(db, {
        approvalId: ref.id,
        decision: 'approve',
        note: 'zero_touch_auto_ack',
      });
      return {
        id: ref.id,
        ...doc,
        createdAt: new Date().toISOString(),
        deduped: false,
        autoAcked: true,
      };
    } catch (err) {
      structuredLog('warn', 'auto_ack.failed', {
        approvalId: ref.id,
        message: err && err.message ? String(err.message).slice(0, 160) : 'unknown',
      });
    }
  }

  return { id: ref.id, ...doc, createdAt: new Date().toISOString(), deduped: false };
}

async function executeWarmup() {
  const results = [];
  for (let i = 0; i < 2; i += 1) {
    for (const path of PROBE_PATHS) {
      results.push(await probeUrl(`${SITE_ORIGIN}${path}`));
    }
    results.push(
      await probeUrl(`${SITE_ORIGIN}/api/create-checkout-session`, { method: 'OPTIONS' })
    );
  }
  const recovered = results.filter((r) => r.healthy).length;
  return {
    ok: recovered >= PROBE_PATHS.length,
    recovered,
    probed: results.length,
  };
}

/**
 * Guardian: re-verify hosting + Stripe + env shapes after remediation.
 * Checkout session IDs use CHECKOUT_SESSION_PREFIX (cs_live_ / cs_test_) from env.
 */
async function runGuardian(db, stripe) {
  const queueReload = await maybeRestartLocalQueue();
  const hosting = await monitorHosting();
  const firestore = await monitorFirestore(db);
  const env = readEnvInventory();
  const stripeHealth = await monitorStripe(stripe);

  const expectedCheckoutPrefix = resolveCheckoutSessionPrefix({
    liveMode: Boolean(env.liveMode),
  });
  const checkoutPrefixOk =
    expectedCheckoutPrefix === 'cs_live_' || expectedCheckoutPrefix === 'cs_test_';

  const checks = {
    hostingOk: hosting.every((p) => p.healthy),
    firestoreOk: firestore.ok,
    stripeOk: stripeHealth.ok,
    envStripeOk: env.stripeSecret.ok,
    envWebhookOk: env.webhookSecret.ok,
    checkoutPrefixOk,
    expectedCheckoutPrefix,
    queueReloaded: Boolean(queueReload && queueReload.ok),
    queueReloadSkipped: Boolean(queueReload && queueReload.skipped),
    note: 'Guardian does not create Checkout Sessions; verifies API + env shapes only.',
  };

  const passed =
    checks.hostingOk &&
    checks.firestoreOk &&
    checks.stripeOk &&
    checks.envStripeOk &&
    checks.envWebhookOk &&
    checks.checkoutPrefixOk;

  return { passed, checks, hosting, firestore, stripe: stripeHealth, env, queueReload };
}

async function writeRemediation(db, entry) {
  const ref = db.collection(REMEDIATIONS_COL).doc();
  await ref.set({
    ...entry,
    id: ref.id,
    createdAt: FieldValue.serverTimestamp(),
  });
  return ref.id;
}

async function writeIncident(db, analysis, cycleId, extra = {}) {
  if (!analysis.findings || !analysis.findings.length) return null;
  const ref = db.collection(INCIDENTS_COL).doc();
  await ref.set({
    id: ref.id,
    cycleId,
    score: analysis.score,
    status: analysis.status,
    findings: analysis.findings,
    errorTypes: (analysis.findings || []).map((f) => mapFindingToErrorType(f.code)),
    requiresHumanReview: Boolean(extra.requiresHumanReview),
    circuitTripped: extra.circuitTripped || [],
    createdAt: FieldValue.serverTimestamp(),
  });
  return ref.id;
}

/**
 * Full MAPE-K cycle with Reflexion: if Guardian fails after safe fix, open HITL rollback ticket.
 */
async function runSelfHealCycle(db, stripe, { trigger = 'scheduler' } = {}) {
  const cycleId = `cycle_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`;
  structuredLog('info', 'cycle.start', { cycleId, trigger });

  // Refresh local queue env (CHECKOUT_SESSION_PREFIX / Hermes) before monitor.
  const queueReload = await maybeRestartLocalQueue();
  structuredLog('info', 'cycle.queue_reload', {
    cycleId,
    ok: Boolean(queueReload && queueReload.ok),
    skipped: Boolean(queueReload && queueReload.skipped),
  });

  // MONITOR
  const observations = {
    hosting: await monitorHosting(),
    firestore: await monitorFirestore(db),
    env: readEnvInventory(),
    stripe: await monitorStripe(stripe),
    iam: await monitorIamProbes(),
    security: await monitorSecurityAlerts(db),
    queueReload,
    deployment: {
      note: 'gcloud/firebase deploy are HITL-only; Functions never rewrite secrets or .env files',
    },
  };

  // PREEMPTIVE: env shape fingerprint (no values) — suppress circuit re-trips on stable drift.
  const prevFp = await loadEnvFingerprintState(db);
  const fp = envDriftFingerprint(observations.env);
  const fpState = await saveEnvFingerprintState(db, fp, prevFp);
  observations.envFingerprint = {
    changed: fpState.changed,
    stableCycles: fpState.stableCycles,
  };

  // ANALYZE
  const analysis = analyze(observations);

  const circuitEvents = [];
  const pausedTypes = new Set();
  for (const finding of analysis.findings || []) {
    const errorType = mapFindingToErrorType(finding.code);
    const isEnvDrift =
      finding.code === 'env_stripe_secret_drift' ||
      finding.code === 'env_webhook_drift' ||
      finding.code === 'env_price_drift';

    // Stable env drift: keep finding for score/HITL, but do not increment circuit hits every 5m.
    if (isEnvDrift && !fpState.changed && fpState.stableCycles > 0) {
      circuitEvents.push({
        errorType,
        state: 'suppressed_stable_env_drift',
        count: 0,
        tripped: false,
        alreadyOpen: true,
        suppressed: true,
      });
      pausedTypes.add(errorType);
      continue;
    }

    const occ = await recordErrorOccurrence(db, errorType, cycleId);
    circuitEvents.push(occ);
    if (occ.tripped || occ.state === 'open') {
      pausedTypes.add(errorType);
      if (occ.tripped && !occ.alreadyOpen) {
        await sendAdminNotify({
          subject: `[Resumora] Circuit OPEN — ${errorType} (human review)`,
          text: [
            'Auto-remediation PAUSED for this error type (circuit trip).',
            `Error type: ${errorType}`,
            `Cycle: ${cycleId}`,
            `Count in window: ${occ.count}`,
            `Window: ${CIRCUIT_WINDOW_MS}ms / trip=${CIRCUIT_TRIP_COUNT} / half-open after ${CIRCUIT_HALF_OPEN_MS}ms`,
            `Dashboard: ${DASHBOARD_URL}`,
            '',
            'FR: Correction automatique en pause — revue humaine requise.',
            'ES: Auto-corrección en pausa — se requiere revisión humana.',
          ].join('\n'),
        });
      }
    }
  }

  const circuitReset = await resetCircuitsIfHealthy(db, analysis);

  // PLAN
  const plan = planRemediations(analysis);

  // EXECUTE (safe only) + HITL for critical
  const executed = [];
  const approvals = [];
  const firstTimeFixes = [];
  const autoPaused = pausedTypes.size > 0;

  for (const finding of analysis.findings || []) {
    const errorType = mapFindingToErrorType(finding.code);
    if (pausedTypes.has(errorType)) continue;
    const first = await autoRemediateFirstTime(db, { errorType, cycleId, analysis });
    firstTimeFixes.push(first);
  }

  for (const action of plan) {
    const guard = preDamageCheck(action, analysis);
    if (!guard.ok) {
      const approval = await createApproval(
        db,
        {
          ...action,
          id: action.id,
          reason: `${action.reason} [preDamageCheck: ${guard.reason}]`,
          risk: RISK.CRITICAL,
        },
        analysis,
        cycleId
      );
      approvals.push({
        actionId: action.id,
        approvalId: approval.id,
        guard: guard.reason,
        deduped: Boolean(approval.deduped),
      });
      if (!approval.deduped) {
        await writeRemediation(db, {
          cycleId,
          actionId: action.id,
          risk: RISK.CRITICAL,
          status: 'awaiting_approval',
          approvalId: approval.id,
          titleKey: action.titleKey,
          guardReason: guard.reason,
        });
      }
      continue;
    }

    if (autoPaused && action.id === 'warmup_endpoints') {
      await writeRemediation(db, {
        cycleId,
        actionId: action.id,
        risk: RISK.SAFE,
        status: 'skipped_circuit_open',
        titleKey: action.titleKey,
      });
      continue;
    }

    if (action.risk === RISK.CRITICAL) {
      const approval = await createApproval(db, action, analysis, cycleId);
      approvals.push({
        actionId: action.id,
        approvalId: approval.id,
        deduped: Boolean(approval.deduped),
      });
      if (!approval.deduped) {
        await writeRemediation(db, {
          cycleId,
          actionId: action.id,
          risk: RISK.CRITICAL,
          status: 'awaiting_approval',
          approvalId: approval.id,
          titleKey: action.titleKey,
        });
      }
      continue;
    }

    if (action.id === 'warmup_endpoints') {
      const attemptGate = await canAttemptRemediation(db, 'HOSTING_WARMUP');
      if (!attemptGate.ok) {
        await writeRemediation(db, {
          cycleId,
          actionId: action.id,
          risk: RISK.SAFE,
          status: 'skipped_remediation_cap',
          titleKey: action.titleKey,
          remediationAttempts: attemptGate.attempts,
        });
        continue;
      }
      await bumpRemediationAttempts(db, 'HOSTING_WARMUP', cycleId);
    }

    let result = { ok: true };
    if (action.id === 'warmup_endpoints') {
      result = await executeWarmup();
    }

    await writeRemediation(db, {
      cycleId,
      actionId: action.id,
      risk: RISK.SAFE,
      status: result.ok ? 'applied' : 'failed',
      result,
      titleKey: action.titleKey,
    });
    executed.push({ actionId: action.id, result });
  }

  // GUARDIAN
  const guardian = await runGuardian(db, stripe);

  // DURABLE STATE MACHINE — ordered phases (IAM → Stripe → … → verify)
  let stateMachine = null;
  try {
    stateMachine = await advanceHealStateMachine(db, {
      analysis,
      guardian,
      cycleId,
    });
    structuredLog('info', 'cycle.state_machine', {
      cycleId,
      status: stateMachine.state && stateMachine.state.status,
      phase: stateMachine.state && stateMachine.state.currentPhase,
      attempt: stateMachine.state && stateMachine.state.attempt,
      blocked: Boolean(stateMachine.blocked),
    });
  } catch (err) {
    structuredLog('warn', 'cycle.state_machine_failed', {
      cycleId,
      message: err && err.message ? String(err.message).slice(0, 200) : 'unknown',
    });
  }

  if (!guardian.passed && executed.length) {
    // Reflexion: safe patch did not restore health → escalate rollback
    const rollback = await createApproval(
      db,
      {
        id: 'auto_rollback_proposal',
        titleKey: 'heal.action.rollback',
        reason: 'Guardian failed after safe remediation — propose Hosting/Functions rollback',
      },
      {
        ...analysis,
        score: Math.min(analysis.score, guardian.passed ? analysis.score : 35),
        status: 'critical',
      },
      cycleId
    );
    approvals.push({ actionId: 'auto_rollback_proposal', approvalId: rollback.id });
    structuredLog('warn', 'reflexion.rollback', { cycleId, approvalId: rollback.id });
  }

  // Zero-touch: clear remaining pending heal approvals when gate is enabled.
  let autoAckResult = { skipped: true };
  try {
    autoAckResult = await bulkAutoApprovePending(db, {
      limit: 25,
      note: `cycle_${cycleId}`,
    });
  } catch (err) {
    structuredLog('warn', 'auto_ack.bulk_failed', {
      message: err && err.message ? String(err.message).slice(0, 160) : 'unknown',
    });
  }

  const incidentId = await writeIncident(db, analysis, cycleId, {
    requiresHumanReview:
      pausedTypes.size > 0 || (analysis.findings || []).some((f) => f.risk === RISK.CRITICAL),
    circuitTripped: circuitEvents.filter((e) => e.tripped).map((e) => e.errorType),
  });

  const snapshot = {
    cycleId,
    trigger,
    updatedAt: FieldValue.serverTimestamp(),
    score: analysis.score,
    status: analysis.status,
    findings: analysis.findings,
    lastObservations: {
      hosting: observations.hosting,
      firestore: observations.firestore,
      stripe: {
        ok: observations.stripe.ok,
        latencyMs: observations.stripe.latencyMs,
        samplePricePresent: observations.stripe.samplePricePresent || false,
        error: observations.stripe.error || null,
      },
      env: observations.env,
    },
    lastPlan: plan,
    lastExecuted: executed,
    lastApprovals: approvals,
    autoAck: {
      enabled: isAutoAckEnabled(),
      bulk: autoAckResult,
    },
    lastGuardian: {
      passed: guardian.passed,
      checks: guardian.checks,
    },
    nextChecklist: buildNextChecklist({
      findings: analysis.findings,
      guardian,
      score: analysis.score,
    }),
    healStateMachine: stateMachine
      ? {
          status: stateMachine.state.status,
          currentPhase: stateMachine.state.currentPhase,
          currentTitle: stateMachine.state.currentTitle,
          currentMode: stateMachine.state.currentMode,
          phaseQueue: stateMachine.state.phaseQueue,
          attempt: stateMachine.state.attempt,
          maxAttempts: stateMachine.state.maxAttempts,
          blocked: Boolean(stateMachine.blocked),
          opsHint: stateMachine.state.opsHint,
          lastError: stateMachine.state.lastError,
        }
      : null,
    lastIncidentId: incidentId,
    lastCircuit: {
      events: circuitEvents.map((e) => ({
        errorType: e.errorType,
        state: e.state,
        count: e.count,
        tripped: e.tripped,
      })),
      pausedTypes: [...pausedTypes],
      resetOnHealthy: circuitReset.reset,
    },
    lastFirstTimeFixes: firstTimeFixes,
    activeRemediations: executed
      .filter((e) => e.result && e.result.ok)
      .map((e) => e.actionId)
      .concat(approvals.map((a) => `pending:${a.actionId}`)),
  };

  // Strip undefined (e.g. stripe.latencyMs when Stripe client missing) without dropping FieldValue.
  const dataToWrite = {
    ...snapshot,
    lastObservations: JSON.parse(JSON.stringify(snapshot.lastObservations)),
  };
  await db.collection(HEALTH_COL).doc(HEALTH_DOC).set(dataToWrite, { merge: true });

  const alert = await maybeSendHealthAlert(db, {
    cycleId,
    analysis,
    guardian,
    incidentId,
  });

  structuredLog('info', 'cycle.end', {
    cycleId,
    score: analysis.score,
    status: analysis.status,
    executed: executed.length,
    approvals: approvals.length,
    guardianPassed: guardian.passed,
    alertSent: Boolean(alert && alert.sent),
  });

  let harnessTask = null;
  try {
    const { maybeCreateHealthTask } = require('./lib/harnessTasks');
    harnessTask = await maybeCreateHealthTask(db, {
      score: analysis.score,
      status: analysis.status,
      findings: analysis.findings,
      cycleId,
    });
  } catch (err) {
    structuredLog('warn', 'harness_task.create_failed', {
      cycleId,
      message: err && err.message ? String(err.message).slice(0, 200) : 'unknown',
    });
  }

  return {
    cycleId,
    score: analysis.score,
    status: analysis.status,
    findings: analysis.findings,
    executed,
    approvals,
    guardian: { passed: guardian.passed, checks: guardian.checks },
    incidentId,
    alert,
    circuit: { pausedTypes: [...pausedTypes], events: circuitEvents },
    firstTimeFixes,
    harnessTask,
  };
}

async function getHealthSnapshot(db) {
  const snap = await db.collection(HEALTH_COL).doc(HEALTH_DOC).get();
  const data = snap.exists ? snap.data() : null;

  async function safeList(col, limit = 25) {
    try {
      const q = await db.collection(col).orderBy('createdAt', 'desc').limit(limit).get();
      return q.docs;
    } catch (_) {
      const q = await db.collection(col).limit(limit).get();
      return q.docs;
    }
  }

  const [incidentDocs, remediationDocs, approvalSnap, notifySnap, circuitSnap, firstFixSnap] =
    await Promise.all([
      safeList(INCIDENTS_COL),
      safeList(REMEDIATIONS_COL),
      db.collection(APPROVALS_COL).where('status', '==', 'pending_approval').limit(25).get(),
      safeList(NOTIFY_COL, 15),
      db.collection(CIRCUIT_COL).limit(40).get(),
      db.collection(FIRST_FIX_COL).limit(40).get(),
    ]);

  async function countQuery(col, field, op, value) {
    try {
      const snap = await db.collection(col).where(field, op, value).limit(50).get();
      return snap.size;
    } catch (_) {
      return 0;
    }
  }

  async function countPublishJobsNeedingReview() {
    try {
      const [failedSnap, partialSnap] = await Promise.all([
        db.collection('media_publish_jobs').where('status', '==', 'failed').limit(50).get(),
        db.collection('media_publish_jobs').where('status', '==', 'partial').limit(50).get(),
      ]);
      return failedSnap.size + partialSnap.size;
    } catch (_) {
      return 0;
    }
  }

  const [humanReviewIncidents, pendingRefunds, failedPublishJobs] = await Promise.all([
    countQuery(INCIDENTS_COL, 'requiresHumanReview', '==', true),
    countQuery('refund_requests', 'status', '==', 'pending_approval'),
    countPublishJobsNeedingReview(),
  ]);

  const serialize = (doc) => {
    const d = doc.data() || {};
    const out = { id: doc.id, ...d };
    for (const key of Object.keys(out)) {
      if (out[key] && typeof out[key].toDate === 'function') {
        out[key] = out[key].toDate().toISOString();
      }
    }
    return out;
  };

  const circuits = circuitSnap.docs.map(serialize);
  const firstTimeFixes = firstFixSnap.docs.map(serialize);
  const firstTried = firstTimeFixes.filter(
    (f) => f.status === 'remediated' || f.status === 'verification_failed'
  );
  const firstOk = firstTimeFixes.filter((f) => f.status === 'remediated').length;
  const rollbacks = remediationDocs
    .map(serialize)
    .filter((r) => r.actionId === 'auto_rollback_proposal' || r.status === 'verification_failed');

  const pendingApprovals = approvalSnap.docs.map(serialize);
  const openCircuits = circuits.filter((c) => c.state === 'open' || c.paused);
  const stripeKycAlert = data?.stripeAccount?.needsAttention ? 1 : 0;
  const criticalAlerts = {
    pendingApprovals: pendingApprovals.length,
    circuitBreakers: openCircuits.length,
    humanReviewIncidents,
    pendingRefunds,
    failedPublishJobs,
    stripeKyc: stripeKycAlert,
  };
  const criticalAlertCount =
    criticalAlerts.pendingApprovals +
    criticalAlerts.circuitBreakers +
    criticalAlerts.humanReviewIncidents +
    criticalAlerts.pendingRefunds +
    criticalAlerts.failedPublishJobs +
    criticalAlerts.stripeKyc;

  const healthBase = data
    ? {
        ...data,
        updatedAt:
          data.updatedAt && typeof data.updatedAt.toDate === 'function'
            ? data.updatedAt.toDate().toISOString()
            : data.updatedAt || null,
        stripeAccount: data.stripeAccount || null,
      }
    : null;

  if (healthBase) {
    healthBase.nextChecklist = buildNextChecklist({
      findings: healthBase.findings || [],
      guardian: healthBase.lastGuardian || null,
      score: healthBase.score,
    });
    healthBase.autoAckEnabled = isAutoAckEnabled();
    try {
      const sm = await loadHealStateMachine(db);
      healthBase.healStateMachine = {
        status: sm.status,
        currentPhase: sm.currentPhase,
        currentTitle: sm.currentTitle,
        currentMode: sm.currentMode,
        phaseQueue: sm.phaseQueue || [],
        attempt: sm.attempt,
        maxAttempts: sm.maxAttempts,
        opsHint: sm.opsHint,
        lastError: sm.lastError,
      };
    } catch (_) {
      /* keep prior healStateMachine on doc if any */
    }
  }

  return {
    health: healthBase,
    incidents: incidentDocs.map(serialize),
    remediations: remediationDocs.map(serialize),
    pendingApprovals,
    notificationHistory: notifySnap.map(serialize),
    circuits,
    circuitBreakers: openCircuits,
    criticalAlertCount,
    criticalAlerts,
    firstTimeFixes,
    firstTimeStats: {
      attempted: firstTried.length,
      remediated: firstOk,
      successRate: firstTried.length > 0 ? Math.round((firstOk / firstTried.length) * 100) : null,
    },
    rollbackHistory: rollbacks.slice(0, 20),
  };
}

/**
 * Human decide on critical remediation proposals.
 * Approved actions are recorded as authorized — actual restart/CDN/env rollback
 * still requires ops credentials; we never mutate secrets from this path.
 */
async function decideApproval(db, { approvalId, decision, note }) {
  const ref = db.collection(APPROVALS_COL).doc(String(approvalId));
  const snap = await ref.get();
  if (!snap.exists) {
    const err = new Error('Approval not found');
    err.statusCode = 404;
    throw err;
  }
  const data = snap.data() || {};
  if (data.status !== 'pending_approval') {
    const err = new Error('Approval already decided');
    err.statusCode = 409;
    throw err;
  }

  const approved = decision === 'approve';
  await ref.set(
    {
      status: approved ? 'approved' : 'rejected',
      decidedAt: FieldValue.serverTimestamp(),
      decisionNote: String(note || '').slice(0, 500),
      // Explicit: we do not auto-rotate secrets or rewrite .env from Functions
      executionNote: approved
        ? 'Authorized for ops runbook (gcloud/firebase). Secrets are never rewritten by the agent.'
        : 'Rejected by admin',
    },
    { merge: true }
  );

  await writeRemediation(db, {
    cycleId: data.cycleId || null,
    actionId: data.actionId,
    risk: RISK.CRITICAL,
    status: approved ? 'approved_awaiting_ops' : 'rejected',
    approvalId,
    titleKey: data.titleKey || null,
  });

  if (approved) {
    const findingCodes = Array.isArray(data.findingCodes) ? data.findingCodes : [];
    for (const code of findingCodes) {
      const errorType = mapFindingToErrorType(code);
      await db.collection(CIRCUIT_COL).doc(circuitDocId(errorType)).set(
        {
          state: 'closed',
          paused: false,
          requiresHumanReview: false,
          hits: [],
          countInWindow: 0,
          closedAt: FieldValue.serverTimestamp(),
          closedReason: 'human_approved',
          updatedAt: FieldValue.serverTimestamp(),
        },
        { merge: true }
      );
    }
    await sendAdminNotify({
      subject: `[Resumora Self-Heal] Approved — ${data.actionId}`,
      text: [
        `Approval ${approvalId} authorized.`,
        'Run the matching gcloud/firebase runbook. Agent will not rewrite secret values.',
        `Action: ${data.actionId}`,
      ].join('\n'),
    });
  }

  return { id: approvalId, status: approved ? 'approved' : 'rejected', actionId: data.actionId };
}

/**
 * Clear pending heal approvals (up to limit) when zero-touch gate is on.
 * Does not rewrite secrets — only closes HITL tickets and circuit breaks.
 */
async function bulkAutoApprovePending(db, { limit = 25, note = 'bulk_zero_touch' } = {}) {
  if (!isAutoAckEnabled()) {
    return { skipped: true, reason: 'SELF_HEAL_ALLOW_GCLOUD|AUTO_ACK not true', approved: [] };
  }
  const snap = await db
    .collection(APPROVALS_COL)
    .where('status', '==', 'pending_approval')
    .limit(Math.max(1, Math.min(50, Number(limit) || 25)))
    .get();
  const approved = [];
  const errors = [];
  for (const doc of snap.docs) {
    const data = doc.data() || {};
    const actionId = String(data.actionId || '');
    if (!isHighConfidenceAction(actionId) && actionId) {
      // Still auto-approve under GCLOUD gate — user requested clear all pending heal approvals.
      // Secrets remain untouched; approve = authorize ops only.
    }
    try {
      await decideApproval(db, {
        approvalId: doc.id,
        decision: 'approve',
        note: `zero_touch:${note}`,
      });
      approved.push({ id: doc.id, actionId });
    } catch (err) {
      errors.push({
        id: doc.id,
        error: err && err.message ? String(err.message).slice(0, 120) : 'failed',
      });
    }
  }
  structuredLog('info', 'auto_ack.bulk', { count: approved.length, errors: errors.length });
  return { skipped: false, approved, errors, count: approved.length };
}

module.exports = {
  assertAdminPassword,
  sendAdminNotify,
  structuredLog,
  readEnvInventory,
  envDriftFingerprint,
  resolveCheckoutSessionPrefix,
  maybeRestartLocalQueue,
  allowProductionStatusSync,
  syncProductionProjectStatus,
  buildNextChecklist,
  advanceHealStateMachine: advanceHealStateMachine,
  runSelfHealCycle,
  getHealthSnapshot,
  decideApproval,
  bulkAutoApprovePending,
  isAutoAckEnabled,
  runGuardian,
  preDamageCheck,
  autoRemediateFirstTime,
  canAttemptRemediation,
  HEALTH_COL,
  HEALTH_DOC,
  CIRCUIT_WINDOW_MS,
  CIRCUIT_TRIP_COUNT,
  CIRCUIT_HALF_OPEN_MS,
  MAX_REMEDIATION_ATTEMPTS,
};

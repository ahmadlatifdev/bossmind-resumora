/**
 * start-bossmind.mjs
 * Starts hermes-idea-queue (HITL :8790 / MCP :8791) then Vite (:5173).
 * No new dependencies — uses Node child_process only.
 *
 * Flow:
 * 1. Detect HITL port (env / hermes .env / default 8790)
 * 2. Write HERMES_API_URL (+ VITE_HERMES_API_URL) into root .env
 * 3. Start hermes-idea-queue auto-recovery (hitl+mcp+monitor)
 * 4. Wait up to 10s for /api/health
 * 5. Start Vite
 */
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = __dirname;
const QUEUE_DIR = path.join(ROOT, 'hermes-idea-queue');
const HEALTH_TIMEOUT_MS = 10_000;
const HEALTH_POLL_MS = 400;
const MIN_NODE = [22, 22, 0];

function assertNodeVersion() {
  const parts = String(process.versions.node || '0')
    .split('.')
    .map((n) => Number(n) || 0);
  const ok =
    parts[0] > MIN_NODE[0] ||
    (parts[0] === MIN_NODE[0] && parts[1] > MIN_NODE[1]) ||
    (parts[0] === MIN_NODE[0] && parts[1] === MIN_NODE[1] && parts[2] >= MIN_NODE[2]);
  if (!ok) {
    console.error(
      `[bossmind] Node ${process.versions.node} is too old. Require >=22.22.0. ` +
        'Run: winget install OpenJS.NodeJS.22 --version 22.23.2 --scope user ' +
        'or .\\scripts\\use-node-22.ps1 then open a new PowerShell. ' +
        'Manual MSI: https://nodejs.org/en/download'
    );
    process.exit(1);
  }
  console.log(`[bossmind] node ${process.versions.node} OK (>=22.22.0)`);
}

function readEnvFile(filePath) {
  if (!fs.existsSync(filePath)) return {};
  const out = {};
  for (const line of fs.readFileSync(filePath, 'utf8').split(/\r?\n/)) {
    const m = line.match(/^([A-Za-z_][A-Za-z0-9_]*)=(.*)$/);
    if (!m) continue;
    let val = m[2] ?? '';
    if (
      (val.startsWith('"') && val.endsWith('"')) ||
      (val.startsWith("'") && val.endsWith("'"))
    ) {
      val = val.slice(1, -1);
    }
    out[m[1]] = val;
  }
  return out;
}

/** Load root .env then .env.local into process.env (local wins). Never logs values. */
function loadRootEnvIntoProcess() {
  const merged = {
    ...readEnvFile(path.join(ROOT, '.env')),
    ...readEnvFile(path.join(ROOT, '.env.local')),
  };
  for (const [k, v] of Object.entries(merged)) {
    if (v == null || v === '') continue;
    // Prefer already-set shell/CI values; fill gaps from files.
    if (process.env[k] == null || process.env[k] === '') {
      process.env[k] = v;
    }
  }
  const admin = Boolean(String(process.env.ADMIN_REFUND_PASSWORD || '').trim());
  const viteAdmin = Boolean(String(process.env.VITE_ADMIN_PASSWORD || '').trim());
  console.log(
    `[bossmind] env loaded ADMIN_REFUND_PASSWORD=${admin ? 'SET' : 'MISSING'} VITE_ADMIN_PASSWORD=${viteAdmin ? 'SET' : 'MISSING'}`
  );
}

function detectHitlPort() {
  const fromProcess = Number(process.env.HITL_PORT || process.env.HERMES_HITL_PORT || '');
  if (Number.isFinite(fromProcess) && fromProcess > 0) return fromProcess;
  const queueEnv = {
    ...readEnvFile(path.join(QUEUE_DIR, '.env')),
    ...readEnvFile(path.join(QUEUE_DIR, '.env.local')),
  };
  const fromFile = Number(queueEnv.HITL_PORT || '');
  if (Number.isFinite(fromFile) && fromFile > 0) return fromFile;
  return 8790;
}

function upsertRootEnv(vars) {
  const envPath = path.join(ROOT, '.env');
  const existing = fs.existsSync(envPath) ? fs.readFileSync(envPath, 'utf8') : '';
  const lines = existing ? existing.split(/\r?\n/) : [];
  const keys = new Set(Object.keys(vars));
  const next = [];
  for (const line of lines) {
    const m = line.match(/^([A-Za-z_][A-Za-z0-9_]*)=/);
    if (m && keys.has(m[1])) continue;
    if (line.length || next.length) next.push(line);
  }
  while (next.length && next[next.length - 1] === '') next.pop();
  for (const [k, v] of Object.entries(vars)) {
    next.push(`${k}=${v}`);
  }
  next.push('');
  fs.writeFileSync(envPath, next.join('\n'), 'utf8');
  console.log(`[bossmind] wrote ${Object.keys(vars).join(', ')} → .env`);
}

async function waitForHealth(url, timeoutMs) {
  const started = Date.now();
  let lastErr = '';
  while (Date.now() - started < timeoutMs) {
    try {
      const res = await fetch(url, { signal: AbortSignal.timeout(1500) });
      if (res.ok) {
        console.log(`[bossmind] health OK ${url} (${Date.now() - started}ms)`);
        return true;
      }
      lastErr = `HTTP ${res.status}`;
    } catch (err) {
      lastErr = err instanceof Error ? err.message : String(err);
    }
    await new Promise((r) => setTimeout(r, HEALTH_POLL_MS));
  }
  console.error(`[bossmind] health check failed after ${timeoutMs}ms: ${lastErr}`);
  return false;
}

function spawnLogged(label, command, args, cwd, env) {
  const child = spawn(command, args, {
    cwd,
    env: { ...process.env, ...env },
    stdio: ['ignore', 'pipe', 'pipe'],
    shell: process.platform === 'win32',
  });
  const prefix = `[${label}] `;
  child.stdout?.on('data', (buf) => {
    for (const line of String(buf).split(/\r?\n/).filter(Boolean)) {
      console.log(prefix + line);
    }
  });
  child.stderr?.on('data', (buf) => {
    for (const line of String(buf).split(/\r?\n/).filter(Boolean)) {
      console.error(prefix + line);
    }
  });
  child.on('exit', (code, signal) => {
    console.error(`[bossmind] ${label} exited code=${code} signal=${signal || ''}`);
  });
  return child;
}

async function ensureQueueBuilt() {
  const entry = path.join(QUEUE_DIR, 'dist', 'index.js');
  if (fs.existsSync(entry)) return;
  console.log('[bossmind] building hermes-idea-queue…');
  await new Promise((resolve, reject) => {
    const child = spawn('npm', ['run', 'build'], {
      cwd: QUEUE_DIR,
      stdio: 'inherit',
      shell: process.platform === 'win32',
    });
    child.on('exit', (code) => (code === 0 ? resolve() : reject(new Error(`queue build ${code}`))));
  });
}

function ensureHermesApiUrlInEnv() {
  const envPath = path.join(ROOT, '.env');
  const existing = readEnvFile(envPath);
  if (String(existing.HERMES_API_URL || '').trim()) {
    console.log('[bossmind] HERMES_API_URL already set in .env (left unchanged)');
    return String(existing.HERMES_API_URL).trim().replace(/\/$/, '');
  }
  const value = 'http://localhost:8791';
  upsertRootEnv({ HERMES_API_URL: value });
  process.env.HERMES_API_URL = value;
  console.log('[bossmind] wrote missing HERMES_API_URL=http://localhost:8791 → .env');
  return value;
}

async function main() {
  assertNodeVersion();
  loadRootEnvIntoProcess();

  const hitlPort = detectHitlPort();
  const mcpPort = Number(process.env.MCP_PORT || 8791) || 8791;
  const hermesHitlUrl = `http://127.0.0.1:${hitlPort}`;
  // HITL OpenAI-compat lives on :8790; MCP reactive link on :8791.
  // Only auto-fill HERMES_API_URL when missing (user-requested localhost:8791).
  ensureHermesApiUrlInEnv();

  // Keep admin passwords in root .env so Hermes child + Vite both see matching names.
  const adminPw = String(process.env.ADMIN_REFUND_PASSWORD || '').trim();
  const viteAdminPw = String(
    process.env.VITE_ADMIN_PASSWORD || process.env.ADMIN_REFUND_PASSWORD || ''
  ).trim();
  const envUpsert = {
    VITE_HERMES_API_URL: hermesHitlUrl,
    HITL_PORT: String(hitlPort),
    MCP_PORT: String(mcpPort),
  };
  if (adminPw) envUpsert.ADMIN_REFUND_PASSWORD = adminPw;
  if (viteAdminPw) envUpsert.VITE_ADMIN_PASSWORD = viteAdminPw;
  upsertRootEnv(envUpsert);

  await ensureQueueBuilt();

  // Local launcher: never PATCH production project status (even if .env has admin passwords).
  const skipProdStatusSync = '1';
  const nodeEnv = String(process.env.NODE_ENV || 'development');
  const hasAdminPw = Boolean(adminPw || viteAdminPw);
  if (!hasAdminPw) {
    console.log(
      '[bossmind] ADMIN_REFUND_PASSWORD / VITE_ADMIN_PASSWORD missing — status:active sync disabled'
    );
  }
  console.log(
    `[bossmind] production status sync SKIPPED for local stack (NODE_ENV=${nodeEnv}, SKIP_PROD_STATUS_SYNC=1)`
  );

  console.log(`[bossmind] starting hermes-idea-queue (HITL :${hitlPort}, MCP :${mcpPort})…`);
  const queue = spawnLogged(
    'hermes',
    'node',
    ['dist/index.js', 'auto-recovery'],
    QUEUE_DIR,
    {
      NODE_ENV: nodeEnv === 'production' ? 'production' : 'development',
      SKIP_PROD_STATUS_SYNC: skipProdStatusSync,
      HITL_PORT: String(hitlPort),
      MCP_PORT: String(mcpPort),
      HERMES_API_URL: hermesHitlUrl,
      ADMIN_REFUND_PASSWORD: adminPw || viteAdminPw,
      VITE_ADMIN_PASSWORD: viteAdminPw || adminPw,
    }
  );

  const healthy = await waitForHealth(`${hermesHitlUrl}/api/health`, HEALTH_TIMEOUT_MS);
  if (!healthy) {
    queue.kill('SIGTERM');
    process.exit(1);
  }

  const mcpReady = await waitForHealth(
    `http://127.0.0.1:${mcpPort}/health`,
    HEALTH_TIMEOUT_MS
  );
  console.log(
    `[hermes] listening on ${mcpPort}${mcpReady ? '' : ' (announced; MCP /health pending)'}`
  );

  console.log('[bossmind] starting Vite on :5173…');
  const vite = spawnLogged(
    'vite',
    'npx',
    ['vite', '--host', '127.0.0.1', '--port', '5173'],
    ROOT,
    {
      HERMES_API_URL: hermesHitlUrl,
      VITE_HERMES_API_URL: hermesHitlUrl,
      ADMIN_REFUND_PASSWORD: adminPw || viteAdminPw,
      VITE_ADMIN_PASSWORD: viteAdminPw || adminPw,
    }
  );

  const viteReady = await waitForHealth('http://127.0.0.1:5173/', 30_000);
  if (viteReady) {
    console.log('[vite] ready on 5173');
  } else {
    console.error('[vite] not ready on 5173 within timeout');
  }

  const shutdown = () => {
    console.log('[bossmind] shutting down…');
    try {
      vite.kill('SIGTERM');
    } catch {
      /* ignore */
    }
    try {
      queue.kill('SIGTERM');
    } catch {
      /* ignore */
    }
    process.exit(0);
  };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);

  vite.on('exit', (code) => {
    try {
      queue.kill('SIGTERM');
    } catch {
      /* ignore */
    }
    process.exit(code || 0);
  });
}

main().catch((err) => {
  console.error('[bossmind] fatal:', err instanceof Error ? err.message : err);
  process.exit(1);
});
